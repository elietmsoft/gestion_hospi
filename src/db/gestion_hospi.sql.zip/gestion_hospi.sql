-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 26 août 2020 à 11:03
-- Version du serveur :  5.7.24
-- Version de PHP : 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestion_hospi`
--

-- --------------------------------------------------------

--
-- Structure de la table `table_accouchement`
--

CREATE TABLE `table_accouchement` (
  `accouchement_id` int(11) NOT NULL,
  `sexe_enfant` varchar(50) NOT NULL,
  `poids_enfant` float DEFAULT NULL,
  `coloration_enfant` varchar(50) NOT NULL,
  `premier_cri_enfant` varchar(50) NOT NULL,
  `etat_enfant` varchar(50) NOT NULL,
  `voie_accouchement` varchar(50) NOT NULL,
  `date` datetime DEFAULT NULL,
  `fiche_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `table_accouchement`
--

INSERT INTO `table_accouchement` (`accouchement_id`, `sexe_enfant`, `poids_enfant`, `coloration_enfant`, `premier_cri_enfant`, `etat_enfant`, `voie_accouchement`, `date`, `fiche_id`) VALUES
(1, 'M', 2, 'noir', 'bien', 'Normal', 'Normale', '2020-08-23 00:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `table_antecedant`
--

CREATE TABLE `table_antecedant` (
  `atcd_id` int(11) NOT NULL,
  `nombre_gda` int(11) DEFAULT NULL,
  `nombre_ffa` int(11) DEFAULT NULL,
  `nombre_evdm` int(11) DEFAULT NULL,
  `nombre_ffaa` int(11) DEFAULT NULL,
  `fiche_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `table_antecedant`
--

INSERT INTO `table_antecedant` (`atcd_id`, `nombre_gda`, `nombre_ffa`, `nombre_evdm`, `nombre_ffaa`, `fiche_id`) VALUES
(1, 10, 10, 10, 10, 1);

-- --------------------------------------------------------

--
-- Structure de la table `table_cpn`
--

CREATE TABLE `table_cpn` (
  `cpn_id` int(11) NOT NULL,
  `poids_mere` float DEFAULT NULL,
  `tension_mere` varchar(50) NOT NULL,
  `position_enfant` varchar(50) NOT NULL,
  `etat_serologique_mere` varchar(50) NOT NULL,
  `glycemie_mere` varchar(50) NOT NULL,
  `fiche_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `table_cpn`
--

INSERT INTO `table_cpn` (`cpn_id`, `poids_mere`, `tension_mere`, `position_enfant`, `etat_serologique_mere`, `glycemie_mere`, `fiche_id`) VALUES
(1, 60, 'Normale', 'Normale', 'Négatif', 'Normale', 1);

-- --------------------------------------------------------

--
-- Structure de la table `table_fiche`
--

CREATE TABLE `table_fiche` (
  `fiche_id` int(11) NOT NULL,
  `nom_mere` varchar(50) NOT NULL,
  `postnom_mere` varchar(50) NOT NULL,
  `prenom_mere` varchar(50) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `etat_civil` varchar(50) NOT NULL,
  `adresse` text,
  `niveau_etude` varchar(50) NOT NULL,
  `nom_marie` varchar(50) NOT NULL,
  `profession_marie` varchar(50) NOT NULL,
  `telephone` int(11) DEFAULT NULL,
  `nationalite` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `table_fiche`
--

INSERT INTO `table_fiche` (`fiche_id`, `nom_mere`, `postnom_mere`, `prenom_mere`, `age`, `etat_civil`, `adresse`, `niveau_etude`, `nom_marie`, `profession_marie`, `telephone`, `nationalite`) VALUES
(1, 'NDELELA', 'MAYOMBO', 'Frida', 35, 'Mariée', '', 'D6', 'MPOMPO', 'Travailleur', 899522267, NULL),
(2, 'NZEBA', 'MAYOMBO', 'Dédé', 33, 'Mariée', '', 'D6', 'ZADIO', 'Travailleur', 822013462, NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `table_accouchement`
--
ALTER TABLE `table_accouchement`
  ADD PRIMARY KEY (`accouchement_id`),
  ADD KEY `fiche_id` (`fiche_id`);

--
-- Index pour la table `table_antecedant`
--
ALTER TABLE `table_antecedant`
  ADD PRIMARY KEY (`atcd_id`),
  ADD KEY `fiche_id` (`fiche_id`);

--
-- Index pour la table `table_cpn`
--
ALTER TABLE `table_cpn`
  ADD PRIMARY KEY (`cpn_id`),
  ADD KEY `fiche_id` (`fiche_id`);

--
-- Index pour la table `table_fiche`
--
ALTER TABLE `table_fiche`
  ADD PRIMARY KEY (`fiche_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `table_accouchement`
--
ALTER TABLE `table_accouchement`
  MODIFY `accouchement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `table_antecedant`
--
ALTER TABLE `table_antecedant`
  MODIFY `atcd_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `table_cpn`
--
ALTER TABLE `table_cpn`
  MODIFY `cpn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `table_fiche`
--
ALTER TABLE `table_fiche`
  MODIFY `fiche_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `table_accouchement`
--
ALTER TABLE `table_accouchement`
  ADD CONSTRAINT `table_accouchement_ibfk_1` FOREIGN KEY (`fiche_id`) REFERENCES `table_fiche` (`fiche_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Contraintes pour la table `table_antecedant`
--
ALTER TABLE `table_antecedant`
  ADD CONSTRAINT `table_antecedant_ibfk_1` FOREIGN KEY (`fiche_id`) REFERENCES `table_fiche` (`fiche_id`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Contraintes pour la table `table_cpn`
--
ALTER TABLE `table_cpn`
  ADD CONSTRAINT `table_cpn_ibfk_1` FOREIGN KEY (`fiche_id`) REFERENCES `table_fiche` (`fiche_id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
